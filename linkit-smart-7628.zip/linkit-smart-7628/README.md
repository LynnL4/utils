# 步骤

## kernel
修改openwrt的target/linux/ramips/dts/LINKIT7688.dts，也可以直接用本目录dts下的LINKIT7688.dts，两处修改（内存和SDHCI）：
Modify openwrt's target/linux/ramips/dts/LINKIT7688.dts, or you can directly use LINKIT7688.dts under dts in this directory, with two modifications (memory and SDHCI).
````
diff --git a/target/linux/ramips/dts/LINKIT7688.dts b/target/linux/ramips/dts/LINKIT7688.dts
index 7f00fbc154..df18df9e90 100644
--- a/target/linux/ramips/dts/LINKIT7688.dts
+++ b/target/linux/ramips/dts/LINKIT7688.dts
@@ -12,7 +12,7 @@
 
        memory@0 {
                device_type = "memory";
-               reg = <0x0 0x8000000>;
+               reg = <0x0 0x4000000>;
        };
 
        pinctrl {
@@ -123,8 +123,6 @@
 
        sdhci@10130000 {
                status = "okay";
-               mediatek,cd-high;
-//             mediatek,cd-poll;
        };
 
        bootstrap {
````

## wifi驱动
修改feeds/linkit/mtk-sdk-wifi/files/lib/wifi/ralink.sh，支持本硬件
Modify feeds/linkit/mtk-sdk-wifi/files/lib/wifi/ralink.sh to support this hardware

````
diff --git a/mtk-sdk-wifi/files/lib/wifi/ralink.sh b/mtk-sdk-wifi/files/lib/wifi/ralink.sh
index 7e60c7a..7c66914 100644
--- a/mtk-sdk-wifi/files/lib/wifi/ralink.sh
+++ b/mtk-sdk-wifi/files/lib/wifi/ralink.sh
@@ -50,7 +50,7 @@ detect_ralink() {
 
        cpu=$(awk 'BEGIN{FS="[ \t]+: MediaTek[ \t]"} /system type/ {print $2}' /proc/cpuinfo | cut -d" " -f1)
        case $cpu in
-       MT7688)
+       MT7688 | MT7628*)
                write_ralink mt_wifi mt7628 ra0 11g 7
                ;;
        esac
````




